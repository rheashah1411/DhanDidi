## Summary

Describe the user-facing change.

## Verification

- [ ] `ruff check .`
- [ ] `pytest`
- [ ] English, Hindi, and Marathi interfaces were checked when visible text changed
- [ ] No real financial documents, credentials, or `.cache` data were committed
